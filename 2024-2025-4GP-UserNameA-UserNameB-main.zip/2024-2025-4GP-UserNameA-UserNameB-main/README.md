# 2024-2025-4GP-UserNameA-UserNameB

## Ma todo liste

- [x] Créer le dépôt
- [x] Modifier le fichier principale de la documentation du repo `README.md`
- [x] Ajout du template pour la shield UNO
